#ifndef Aardvark_H
#define Aardvark_H
#include <Arduino.h>
#include <Wire.h>

class DiceDevice{
    private:
        void initLedDriver();
        uint8_t busRead(uint8_t, uint8_t);
        void busWrite(uint8_t, uint8_t, uint8_t);
        uint8_t initEEPROM(uint32_t);
    public:
        DiceDevice();
        ~DiceDevice();
        void begin();
        uint8_t getKeys();
        int8_t getTilt(uint8_t);
        uint16_t getBattery();
        void ledWrite(uint8_t);
        void ledBlank();
        void ledBrightness(uint8_t);
        void lcdBacklight(uint8_t);
        void lcdContrast(uint8_t);
        uint8_t readEEPROM(uint32_t);
        void readEEPROM(uint32_t, uint8_t [], uint16_t);
        void writeEEPROM(uint32_t, uint8_t);
        void writeEEPROM(uint32_t, uint8_t [], uint16_t);
};
#endif
