#include <DiceDevice.h>

const uint8_t EEPROM_ADDRESS = 0x50;
const uint8_t DIGPOT_ADDRESS = 0x2E;
const uint8_t LEDDRV_ADDRESS = 0x60;
const uint8_t ACCEL_ADDRESS = 0x15;
const uint8_t BATTERY_PIN = 31;
const uint8_t BACKLIGHT_PIN = 4;
const uint16_t AD_TO_VOLTS = 48828;
const uint16_t ledTensMap[] = {57357,8200,49166,24590,8203,24583,57351,8204,57359,24591};
const uint16_t ledOnesMap[] = {3440,320,3680,1888,848,1840,3888,352,3952,1904};
const uint8_t keyMap[] = {11, 12, 13, 14};
const uint8_t TILT_THRESH = 32;
const uint8_t DEBOUNCE_DELAY = 100;
uint32_t keyTimer[] = {0, 0, 0, 0};
uint32_t tiltTimer[] = {0, 0, 0, 0};
uint8_t ledIntensity = 127;

//Constructor
DiceDevice::DiceDevice(){}

//Destructor
DiceDevice::~DiceDevice(){}

void DiceDevice::begin() {
    Wire.begin();
    Wire.setClock(400000); //Use fast i2c
    ADCSRA = ADCSRA & 0b11111000; //Increase ADC speed
    ADCSRA = ADCSRA | 0b100; // by changing prescaler to /16
    lcdContrast(10); //Set contrast pot to nominal
    lcdBacklight(0);  //Turn off LCD back light

    for (uint8_t i = 0; i < 4; i++){
        pinMode(keyMap[i], INPUT_PULLUP);
        keyTimer[i] = millis();
        tiltTimer[i] = millis();
    }

    initLedDriver();
}

void DiceDevice::initLedDriver(){
  busWrite(LEDDRV_ADDRESS, 0x00, 0b00000000); //Turn on oscillator bit4 and turn off LED All Call address
  busWrite(LEDDRV_ADDRESS, 0x01, 0b00100000); //Enable DMBLNK for blinking LEDs
  busWrite(LEDDRV_ADDRESS, 0x12, 255); //Set blink duty cycle to 100% (turns off blink)
  busWrite(LEDDRV_ADDRESS, 0x13, 13); //Set blink speed to .5 second
  for (uint8_t i = 0x14; i <= 0x17; i++){
    busWrite(LEDDRV_ADDRESS, i, 0xFF);
  }
}

uint8_t DiceDevice::getKeys() {
  uint8_t keyPress = 0;
  for (uint8_t i = 0; i < 4; i++){
      if (digitalRead(keyMap[i]) == 0){
        if (( millis() - keyTimer[i] ) > DEBOUNCE_DELAY){
          keyPress = i + 1;
          keyTimer[i] = millis();
        }
      } else {
        keyTimer[i] = millis();
      }
  }

  for (uint8_t i = 0; i < 2; i++){
    int8_t tilt = getTilt(i);
    if ( abs(tilt) > TILT_THRESH ){
      if ( tilt >= 0 ){
        if ( millis() - tiltTimer[i * 2] > DEBOUNCE_DELAY ){
          keyPress = i * 2 + 1;
          tiltTimer[i * 2] = millis();
        }
      } else {
        if ( millis() - tiltTimer[i * 2 + 1] > DEBOUNCE_DELAY ){
          keyPress = i * 2 + 2;
          tiltTimer[i * 2 + 1] = millis();
        }
      }
    } else {
      tiltTimer[i * 2] = millis();
      tiltTimer[i * 2 + 1] = millis();
    }
  }
  return keyPress;
}

int8_t DiceDevice::getTilt(uint8_t axis){
    int8_t tilt = 0;
    if (axis == 0 || axis == 1){
        tilt = busRead(ACCEL_ADDRESS, axis);
        if ( bitRead(tilt, 7) == 1 ){ //If negative number...
            tilt = -byte(~tilt + 1); //convert 2's complement
        }
    }
    return tilt;
}

uint16_t DiceDevice::getBattery(){
    uint32_t battery = analogRead(BATTERY_PIN);
    battery = ((battery * AD_TO_VOLTS)/10000);
    return (uint16_t)battery;
}

void DiceDevice::ledWrite(uint8_t number){
    uint8_t ones = number % 10;
    uint8_t tens = number / 10;
    uint16_t numberMap = ledOnesMap[ones] | ledTensMap[tens];
    for (uint8_t i = 0; i < 16; i++){
        if (bitRead(numberMap, i) == 1){
            busWrite(LEDDRV_ADDRESS, i + 2, ledIntensity);
        } else {
            busWrite(LEDDRV_ADDRESS, i + 2, 0);
        }
    }
}

void DiceDevice::ledBlank(){
    for (uint8_t i = 0x02; i < 0x12; i++){
       busWrite(LEDDRV_ADDRESS, i, 0);
    }
}

void DiceDevice::ledBrightness(uint8_t intensity){
    ledIntensity = intensity;
}

void DiceDevice::lcdBacklight(uint8_t intensity){
    intensity = 255 - intensity;
    analogWrite(BACKLIGHT_PIN, intensity);
}

void DiceDevice::lcdContrast(uint8_t contrast){
    busWrite(DIGPOT_ADDRESS, 0, contrast);
}

uint8_t DiceDevice::readEEPROM(uint32_t address){
    uint8_t value = 0;
    uint8_t device = initEEPROM(address);
    Wire.endTransmission(0);
    Wire.requestFrom(device, (uint8_t)1);
    if (Wire.available()) value = Wire.read();
    return value;
}

void DiceDevice::readEEPROM(uint32_t address, uint8_t values[], uint16_t quantity){
    uint8_t device = initEEPROM(address);
    Wire.endTransmission(0);
    Wire.requestFrom(device, quantity);
    for (uint8_t i = 0; i < quantity; i++){
        if (Wire.available()) values[i] = Wire.read();
    }
}

void DiceDevice::writeEEPROM(uint32_t address, uint8_t value){
    initEEPROM(address);
    Wire.write(value);
    Wire.endTransmission();
}

void DiceDevice::writeEEPROM(uint32_t address, uint8_t values[], uint16_t quantity){
    initEEPROM(address);
    Wire.write(values, quantity);
    Wire.endTransmission();
}

uint8_t DiceDevice::initEEPROM(uint32_t address){
    //Required to take A16 from address and OR it into device address
    uint8_t _device = EEPROM_ADDRESS | bitRead(address, 16);
    Wire.beginTransmission(_device);
    //Take MSB and LSB from 32-bit address
    Wire.write((uint8_t)((address >> 8) & 0xFF));
    Wire.write((uint8_t)(address & 0xFF));
    return _device;
}

uint8_t DiceDevice::busRead(uint8_t device, uint8_t address){
    uint8_t value = 0;
    Wire.beginTransmission(device);
    Wire.write(address);
    Wire.endTransmission(false);
    Wire.requestFrom(device, (uint8_t)1);
    if (Wire.available()) value = Wire.read();
    return value;
}

void DiceDevice::busWrite(uint8_t device, uint8_t address, uint8_t value){
    Wire.beginTransmission(device);
    Wire.write(address);
    Wire.write(value);
    Wire.endTransmission();
}
